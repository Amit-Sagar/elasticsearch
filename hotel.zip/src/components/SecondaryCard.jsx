import React, { Component } from 'react'
import UTILS from '../utils/utils'
import { Card, Input, Form, Button, Space, Select, Pagination, Checkbox,Radio } from 'antd'
import 'antd/dist/antd.css'
import {
  FilterOutlined,
  OrderedListOutlined,
  SortAscendingOutlined,
  SortDescendingOutlined,
  TableOutlined,
  EnvironmentOutlined,
} from '@ant-design/icons'
export class Cards extends Component {
  constructor(props) {
    super(props)
    this.state = {
      filter: '',
      refine: '',
      offset:0,
      items: [],
      per_page: 6,
      current_page: 0,
      isinitialLoadingElastic: true,
      isinitialLoadingDrupal: true,
      isLoading: true,
      isLoadingMore: true,
      isError: false,
      errorMsg: '',
      search: false,
      searchedText: '',
      isFilterType: 'relevance',
      filterList: [],
      activeFilter: [],
      refineActive: false,
      filterActive: false,
      sortActive: false,
      typeFlag: false,
      filterFields: [
        'title',
        'body',
        'sub_title',
        'field_summary_subtitle',
        'summary_title',
        'field_itinerary_summary_title',
        'itinerary_body',
        'itinerary_sub_title',
        'itinerary_title',
        'itinerary_items_body',
        'itinerary_items_title',
        'listicle_body',
        'listicle_title',
        'itinerary_section_body',
        'itinerary_section_sub_title',
      ],
    }
  }
  

  componentDidMount() {
    let paramsQuery = UTILS.queryStringParse(decodeURI(window.location.search))
    let search_query = paramsQuery.q ? paramsQuery.q : null
    let refine_query = paramsQuery.r ? paramsQuery.r : ''
    if (search_query) {
      this.setState(
        {
          current_page: 0,
          isLoading: true,
          search: true,
          searchedText: search_query,
          filter: search_query,
          refine: refine_query,
          items: [],
        },
        () => {
          let requestOptions = this.createRequestOptions()
          this.makeHttpRequest(requestOptions)
        },
      )
    } else {
      let requestOptions = {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          from: this.state.per_page * this.state.current_page,
          size: this.state.per_page,
        }),
      }
      window.history.pushState({}, document.title, '/' + 'search')
      this.makeHttpRequest(requestOptions)
    }
    this.makeDrupalRequest()
  }
  // onFilterChange(filter) {
  //   const { filterList, activeFilter } = this.state
  //   if (filter === 'ALL') {
  //     if (activeFilter.length === filterList.length) {
  //       this.setState(
  //         {
  //           activeFilter: [],
  //           current_page: 0,
  //           isLoading: true,
  //           items: [],
  //           typeFlag: true,
  //         },
  //         () => {
  //           let requestOptions = this.createRequestOptions()
  //           this.modifyHttpRequest(requestOptions)
  //         },
  //       )
  //     } else {
  //       this.setState(
  //         {
  //           activeFilter: filterList.map((filter) => filter.key),
  //           current_page: 0,
  //           isLoading: true,
  //           items: [],
  //           typeFlag: true,
  //         },
  //         () => {
  //           let requestOptions = this.createRequestOptions()
  //           this.modifyHttpRequest(requestOptions)
  //         },
  //       )
  //     }
  //   } else {
  //     if (activeFilter.includes(filter)) {
  //       const filterIndex = activeFilter.indexOf(filter)
  //       const newFilter = [...activeFilter]
  //       newFilter.splice(filterIndex, 1)
  //       this.setState(
  //         {
  //           activeFilter: newFilter,
  //           current_page: 0,
  //           isLoading: true,
  //           items: [],
  //           typeFlag: true,
  //         },
  //         () => {
  //           let requestOptions = this.createRequestOptions()
  //           this.modifyHttpRequest(requestOptions)
  //         },
  //       )
  //     } else {
  //       this.setState(
  //         {
  //           activeFilter: [...activeFilter, filter],
  //           current_page: 0,
  //           isLoading: true,
  //           items: [],
  //           typeFlag: true,
  //         },
  //         () => {
  //           let requestOptions = this.createRequestOptions()
  //           this.modifyHttpRequest(requestOptions)
  //         },
  //       )
  //     }
  //   }
  // }
  // handleFilter = (e, type) => {
  //   this.setState(
  //     {
  //       isFilterType: type,
  //       current_page: 0,
  //       isLoading: true,
  //       items: [],
  //     },
  //     () => {
  //       let requestOptions = this.createRequestOptions();
  //       this.modifyHttpRequest(requestOptions);
  //     }
  //   );
  // };

  makeHttpRequest = (options) => {
    fetch(
      'https://search-washingtond8-prod-kz2b5bkdr37mxlfu5v3jksydom.us-east-1.es.amazonaws.com/elasticsearch_index_washingtond8_new_washington_dc/_search',
      options,
    )
      .then(async (response) => {
        const data = await response.json()
        if (!response.ok) {
          const error = (data && data.message) || response.status
          this.setState({
            isError: true,
            isinitialLoadingElastic: false,
            isLoading: false,
            isLoadingMore: false,
            errorMsg: error,
          })
          return Promise.reject(error)
        }
        console.log(data)
        this.setState({
          items: [...this.state.items, ...data.hits.hits],
          totalCount: data.hits.total.value,
          current_page: this.state.current_page + 1,
          isinitialLoadingElastic: false,
          isLoadingMore: false,
          isLoading: false,
        })
      })
      .catch((error) => {
        this.setState({
          isError: true,
          isinitialLoadingElastic: false,
          isLoading: false,
          isLoadingMore: false,
          errorMsg: error,
        })
        console.error('There was an error!', error)
      })
  }

  makeDrupalRequest = () => {
    const data = {
      article: 'Article',
      business: 'Business',
      category_listing: 'Category Listing',
      deals: 'Deals',
      department_page: 'Department Page',
      event: 'Event',
      general_article: 'General Article',
      general_page: 'General Page',
      itinerary: 'Itinerary',
      listicle: 'Listicle',
      neighborhood: 'Neighborhood',
      overview_page: 'Overview Page',
    }

    let modifyData = Object.keys(data).map((key) => ({
      key,
      value: data[key],
    }))
    this.setState({
      filterList: modifyData,
      isinitialLoadingDrupal: false,
      isLoadingMore: false,
      isLoading: false,
    })
  }
  modifyHttpRequest = (requestOptions) => {
    fetch(
      'https://search-washingtond8-prod-kz2b5bkdr37mxlfu5v3jksydom.us-east-1.es.amazonaws.com/elasticsearch_index_washingtond8_new_washington_dc/_search',
      requestOptions,
    )
      .then(async (response) => {
        const data = await response.json()
        if (!response.ok) {
          const error = (data && data.message) || response.status
          this.setState({
            isError: true,
            isLoading: false,
            isLoadingMore: false,
            errorMsg: error,
          })
          return Promise.reject(error)
        }

        this.setState({
          items: data.hits.hits,
          current_page: this.state.current_page + 1,
          totalCount: data.hits.total.value,
          isLoading: false,
          isLoadingMore: false,
        })
      })
      .catch((error) => {
        this.setState({
          isError: true,
          isLoading: false,
          errorMsg: error,
          isLoadingMore: false,
        })
        console.error('There was an error!', error)
      })
  }

  loadMore = () => {
    this.setState({ isLoadingMore: true })
    let requestOptions = this.createRequestOptions()
    this.makeHttpRequest(requestOptions)
  }

  handleChange = (event) => {
    this.setState({ filter: event.target.value })
  }

  handleRefineChange = (event) => {
    this.setState({ refine: event.target.value })
  }

  _handleKeyDown = (e) => {
    if (
      e.key === 'Enter' &&
      this.state.refine !== '' &&
      this.state.filter !== ''
    ) {
      this.setState(
        {
          current_page: 0,
          isLoading: true,
          search: true,
          searchedText: [this.state.filter, this.state.refine].join(' ').trim(),
          items: [],
        },
        () => {
          if (window.history.pushState) {
            var newurl =
              window.location.protocol +
              '//' +
              window.location.host +
              window.location.pathname +
              '?q=' +
              this.state.filter +
              '&r=' +
              this.state.refine
            window.history.pushState({ path: newurl }, '', newurl)
          }
          let requestOptions = this.createRequestOptions()
          this.modifyHttpRequest(requestOptions)
        },
      )
    }
  }
  _handleKeySearch = (e) => {
    if (e.key === 'Enter' && this.state.filter !== '') {
      this.handleClick()
    }
  }
  handleClear = () => {
    this.setState(
      {
        current_page: 0,
        isLoading: true,
        search: false,
        searchedText: '',
        filter: '',
        refine: '',
        items: [],
        activeFilter: [],
        isFilterType: 'relevance',
      },
      () => {
        window.history.pushState({}, document.title, '/' + 'search')
        let requestOptions = this.createRequestOptions()
        this.modifyHttpRequest(requestOptions)
      },
    )
  }
  createRequestOptions = () => {
    if (this.state.filter === '') {
      let requestbody = {
        from: this.state.per_page * this.state.current_page,
        size: this.state.per_page,
      }
      if (this.state.isFilterType === 'date') {
        requestbody['sort'] = [{ created: { order: 'desc' } }]
      }
      if (this.state.activeFilter.length) {
        requestbody['query'] = {
          bool: {
            filter: [
              {
                terms: {
                  type: this.state.activeFilter,
                },
              },
            ],
          },
        }
      }
      let requestOptions = {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(requestbody),
      }
      return requestOptions
    } else {
      let requestbody = {}
      if (this.state.refine === '') {
        requestbody = {
          from: this.state.per_page * this.state.current_page,
          size: this.state.per_page,
          query: {
            bool: {
              must: [
                {
                  exists: {
                    field: 'nid',
                  },
                },
                {
                  match: {
                    status: 'true',
                  },
                },
                {
                  multi_match: {
                    query: this.state.filter,
                    type: 'best_fields',
                    operator: 'and',
                    fields: this.state.filterFields,
                  },
                },
              ],
            },
          },
        }
      } else {
        requestbody = {
          from: this.state.per_page * this.state.current_page,
          size: this.state.per_page,
          query: {
            bool: {
              must: [
                {
                  exists: {
                    field: 'nid',
                  },
                },
                {
                  match: {
                    status: 'true',
                  },
                },
                {
                  multi_match: {
                    query: this.state.filter,
                    type: 'best_fields',
                    operator: 'and',
                    fields: this.state.filterFields,
                  },
                },
              ],
              filter: [
                {
                  multi_match: {
                    query: this.state.refine,
                    lenient: true,
                    type: 'phrase_prefix',
                    fields: this.state.filterFields,
                  },
                },
              ],
            },
          },
        }
      }

      if (this.state.isFilterType === 'date') {
        requestbody['sort'] = [{ created: { order: 'desc' } }]
      }
      if (this.state.activeFilter.length && !(this.state.refine === '')) {
        requestbody['query']['bool']['filter'].push({
          terms: {
            type: this.state.activeFilter,
          },
        })
      } else if (this.state.activeFilter.length) {
        requestbody['query']['bool']['filter'] = [
          {
            terms: {
              type: this.state.activeFilter,
            },
          },
        ]
      }
      let requestOptions = {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(requestbody),
      }
      return requestOptions
    }
  }
  changeRefineToggle = () => {
    const currentState = this.state.refineActive
    this.setState({ refineActive: !currentState })
  }

  changeSortingToggle = () => {
    const currentState = this.state.sortActive
    this.setState({ sortActive: !currentState })
  }

  changeFilterToggle = () => {
    const currentState = this.state.filterActive
    this.setState({ filterActive: !currentState })
  }

  handleClick = () => {
    if (this.state.filter === '') {
      this.setState(
        {
          current_page: 0,
          isLoading: true,
          search: false,
          searchedText: '',
          refine: '',
          items: [],
        },
        () => {
          window.history.pushState({}, document.title, '/' + 'search')
          let requestOptions = this.createRequestOptions()
          this.modifyHttpRequest(requestOptions)
        },
      )
    } else {
      this.setState(
        {
          current_page: 0,
          isLoading: true,
          search: true,
          searchedText: [this.state.filter, this.state.refine].join(' ').trim(),
          items: [],
        },
        () => {
          if (window.history.pushState) {
            var newurl =
              window.location.protocol +
              '//' +
              window.location.host +
              window.location.pathname +
              '?q=' +
              this.state.filter +
              '&r=' +
              this.state.refine
            window.history.pushState({ path: newurl }, '', newurl)
          }
          let requestOptions = this.createRequestOptions()
          this.modifyHttpRequest(requestOptions)
        },
      )
    }
  }
  viewDetailsHandler = (nid) => {
    let url = 'https://dev.washington-d8.oslabs.app' + '/node/' + nid
    window.location.href = `${url}`
  }
  onChange(value) {
    console.log(value)
    this.setState(
      {
        isFilterType: value,
        current_page: 0,
        isLoading: true,
        items: [],
      },
      () => {
        let requestOptions = this.createRequestOptions()
        this.modifyHttpRequest(requestOptions)
      },
    )

    if (value == 'relevance') {
      this.setState()
    }
    if (value == 'date') {
      this.setState()
    }
  }

 
  handlePageClick = (e) => {
    const selectedPage = e.selected;
    const offset = selectedPage * this.state.per_page;

    this.setState({
        current_page: selectedPage,
        offset: offset
    }, () => {
        this.makeHttpRequest()
    });

};
  
   onFilterChange (filter){
 
   }


    onFilterChange(checkedValues) {
    console.log("checked = ", checkedValues);
  }
   neighbourhood = [
    "Boca Grande & Outer Island",
    "Bonita Spring & Estero",
    "Cape Coral",
    "Fort Myers Beach",
    "Fort Myres",
    "North Fort Myres",
  ];
   categories = ["Bed & Breakfast", "Condo", "Cottage", "Hotel", "Resort"];
   amenities = [
    "BeachAccess",
    "Island",
    "FloridaGreenLodging",
    "Laundry",
    "Washer / DryerOn - Site",
    "Radio",
  ];
   options = [
    { label: "Boca Grande & Outer Island", value: "Boca Grande & Outer Island" },
    { label: "Bonita Spring & Estero", value: "Bonita Spring & Estero" },
    { label: "Cape Coral", value: "Cape Coral" },
    { label: "Fort Myers Beach", value: "Fort Myers Beach" },
    { label: "Fort Myres", value: "Fort Myres" },
    { label: "North Fort Myres", value: "North Fort Myres" },
    { label: "Bed & Breakfast", value: "Bed & Breakfast" },
    { label: "Condo", value: "Condo" },
    { label: "Cottage", value: "Cottage" },
    { label: "Hotel", value: "CHotelape" },
    { label: "Resort", value: "Resort" },
    { label: "BeachAccess", value: "BeachAccess" },
    { label: "Island", value: "Island" },
    { label: "Laundry", value: "Laundry" },
    { label: "Washer / DryerOn - Site", value: "Washer / DryerOn - Site" },
    { label: "Radio", value: "Radio" },
  ];
  
  render() {
    let {
      isFilterType,
      isLoading,
      search,
      items,
      errorMsg,
      isError,
      filter,
      totalCount,
      searchedText,
      current_page,
      per_page,
      isinitialLoadingElastic,
      isinitialLoadingDrupal,
      filterList,
      activeFilter,
      isLoadingMore,
      refine,
      typeFlag,
    } = this.state
    const { Option } = Select
    console.log(items)
    
    return (
      <div>
      <div style={{ margin: "5%", display: "flex" }}>
        <Card title="Filters" extra={<FilterOutlined/>} style={{ width: "30%" }}>
        <Card
          type="inner"
          bordered={false}
          title="Neighborhood"
          extra={<a href="#">More</a>}
        >
          <Radio.Group >
            <Space direction="vertical">
              <Checkbox.Group
              direction="vertical"
                options={this.neighbourhood}
                defaultValue={["Boca Grande & Outer Island"]}
                onChange={this.onFilterChange}
              />
              {/* <Radio>Boca Grande & Outer Island</Radio>
              <Radio>Bonita Spring & Estero</Radio>
              <Radio>Cape Coral</Radio>
              <Radio>Fort Myers Beach</Radio>
              <Radio>Fort Myres</Radio>
              <Radio>North Fort Myres</Radio> */}
            </Space>
          </Radio.Group>
        </Card>
        <Card
          style={{ marginTop: 16 }}
          bordered={false}
          type="inner"
          title="Categories"
          extra={<a href="#">More</a>}
        >
          <Radio.Group>
            <Space direction="vertical">
              <Checkbox.Group
              style={{ flex:1, flexDirection: "column", backgroundColor:'cream'}}
                options={this.categories}
                defaultValue={["Bed & Breakfast"]}
                onChange={this.onFilterChange}
              />
              {/* <Radio>Bed & Breakfast</Radio>
              <Radio>Condo</Radio>
              <Radio>Cottage</Radio>
              <Radio>Hotel</Radio>
              <Radio>Resort</Radio> */}
            </Space>
          </Radio.Group>
        </Card>
        <Card
          style={{ marginTop: 16 }}
          bordered={false}
          type="inner"
          title="Amenities"
          extra={<a href="#">More</a>}
        >
          <Radio.Group>
            <Space direction="vertical">
              <Checkbox.Group
                options={this.amenities}
                defaultValue={["BeachAccess"]}
                onChange={this.onFilterChange}
              />
              {/* <Radio>Beach Access</Radio>
              <Radio>Island</Radio>
              <Radio>Florida Green Lodging</Radio>
              <Radio>Laundry</Radio>
              <Radio>Washer/Dryer On-Site</Radio>
              <Radio>Radio</Radio> */}
            </Space>
          </Radio.Group>
        </Card>
      </Card>

       <div>
        <div style={{ marginTop: '3%' }}>
          <Select
            placeholder="Sort By"
            size="large"
            style={{ width: 450, marginLeft: '20px' }}
            // onChange={() => {
            //   if (target.onClick == "relevance") {
            //     console.log("hgsh");
            //   }
            // }}
            onChange={(e) => this.onChange(e, this.value)}
          >
            <Option value="relevance">RELEVANCE</Option>
            <Option value="date">DATE</Option>
          </Select>
          <Button
            type="primary"
            style={{ marginLeft: '10px' }}
            // onClick={console.log("hello")}
          >
            <span>
              <SortAscendingOutlined />
            </span>
          </Button>
          <Button type="primary" style={{ marginLeft: '10px' }}>
            <span>
              <SortDescendingOutlined />
            </span>
          </Button>
          <Button type="primary" 
          style={{ marginLeft: "18%" }}>
            <span>
              <TableOutlined />
            </span>
          </Button>
          <Button type="primary" style={{ marginLeft: "10px" }}>
            <span>
              <OrderedListOutlined />
            </span>
          </Button>
          <Button type="primary" style={{ marginLeft: "10px" }}>
            <span>
              <EnvironmentOutlined />
            </span>
          </Button>
        </div>

        {items.map((item, index) => {
          {
            console.log(item)
          }
          return (
            <React.Fragment>
              <Card
              id="card"
                hoverable
                style={{
                  width: '70vw',
                  margin: '5%',
                  marginLeft: '2%',
                  height: 225,
                }}
              >
                <div style={{ display: 'flex', flexDirection: 'row' }}>
                  <img
                    alt="example"
                    src={`https://washington.org/${item._source.thumbnail_images}`}
                  />
                  <div style={{ paddingLeft: '20px' }}>
                    <h2>{item._source.title}</h2>

                    <p>{item._source.card_body}</p>
                  </div>
                </div>
              </Card>
            </React.Fragment>
          )
        })}
        </div>

  {/* <Pagination current={this.state.current_page} onChange={this.handlePageClick} total={50} /> */} 
        
      </div>
      {!isLoading &&
          !isLoadingMore &&
          items.length > 0 &&
          current_page < Math.ceil(totalCount / per_page) && (
            <div className="col-lg-12 col-md-12 text-center search-results-loadmore">
              <div className="icon--line">
                <hr className="line line--vertical line--smoky" />
                <span className="mdi mdi-star"></span>
              </div>
              <div className="btn--loadmore">
                <button
                  data-target="_blank"
                  data-text="LOAD MORE"
                  aria-label="button"
                  className="btn btn--primary"
                  onClick={this.loadMore}
                >
                  <span>LOAD MORE</span>
                </button>
              </div>
            </div>
          )}
      </div>
    )
  }
}

export default Cards
