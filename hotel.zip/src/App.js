import Cards from './components/Card';
// import "./App.css";

function App() {
  return (
    <div className="App">
      <Cards/>
    </div>
  );
}

export default App;
